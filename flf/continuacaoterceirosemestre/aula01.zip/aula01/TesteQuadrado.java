package com.flf.continuacaoterceirosemestre.aula01;

import java.util.Scanner;

public class TesteQuadrado {
	
	public static void main(String[] args) {
		
		AreaQuadrado q1 = new AreaQuadrado(10, 10, 10, 1);
		
		
		
		System.out.println(q1.area());
		
		q1.saberQuadrado();
	}
}
